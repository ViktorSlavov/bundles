Discovery and Renewal workflows that SSH into given machines and discovers ssh keys.
Renewal workflows gets triggered based on automation rules set in Concert and renews expired SSH Keys.